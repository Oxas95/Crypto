#include "SS_SM.h"

//algorithme d'exponentiation rapide (square and multiply)




//test de primalité de Solovay-Strassen

bool Solovay-Strassen(mpz_t n, long long int k){
	return true;
}

