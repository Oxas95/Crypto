#include "jacobi.h"

mpz_t pgcd(mpz_t a, mpz_t b){
	mpz_t res;
	mpz_init_set_str(res, "123456", 0);
	
	return res;
}
